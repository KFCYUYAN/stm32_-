#ifndef _MOTOR_H

#define _MOTOR_H

void MotorInit(void);

void Turnleft(void);

void Turnright(void);

void Turnback(void);

void Turnfront(void);

void Stop(void);

void Leftaround(void);

void Rightaround(void);

#endif 
